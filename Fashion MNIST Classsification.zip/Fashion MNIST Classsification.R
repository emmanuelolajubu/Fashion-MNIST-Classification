# Load necessary libraries
library(keras)
library(tensorflow)

# Load Fashion MNIST dataset
fashion_mnist <- dataset_fashion_mnist()

# Preprocess data
train_images <- fashion_mnist$train$images / 255
test_images <- fashion_mnist$test$images / 255
train_labels <- to_categorical(as.integer(fashion_mnist$train$labels), num_classes = 10)
test_labels <- to_categorical(as.integer(fashion_mnist$test$labels), num_classes = 10)

# Define model architecture
model <- sequential() %>%
  layer_conv_2d(
    filters = 32,
    kernel_size = c(3, 3),
    activation = "relu",
    input_shape = c(28, 28, 1)
  ) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(
    filters = 64,
    kernel_size = c(3, 3),
    activation = "relu"
  ) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_flatten() %>%
  layer_dense(
    units = 128,
    activation = "relu"
  ) %>%
  layer_dense(
    units = 10,
    activation = "softmax"
  )

# Compile model
model %>% compile(
  optimizer = "adam",
  loss = "categorical_crossentropy",
  metrics = c("accuracy")
)

# Train model
model %>% fit(
  train_images,
  train_labels,
  batch_size = 128,
  epochs = 10,
  validation_data = list(test_images, test_labels)
)

# Make predictions on two images
predictions <- model %>% predict(test_images[1:2, , ,])

# Print predicted labels
pred_labels <- apply(predictions, 1, which.max)
print(pred_labels)
